# Text Statistics Counter — Project #107

A simple Python app that counts words, characters, sentences and the
most frequent words in a text. It saves every analysis on your computer
(JSON + CSV), lets you search old analyses, shows a summary, and can
export reports. It uses **only the Python standard library** — no extra
installs needed.

## How to run

You need Python 3.10 or newer. There are two ways to use the app —
both share the same saved records, so the terminal and the dashboard
see the same library.

### 1. Terminal app (no extra installs)

The menu app uses **only the Python standard library**. From this folder:

```
python3 run.py
```

That is all. A menu appears. Pick a number and press Enter.

### 2. Streamlit dashboard (needs one install)

The dashboard is a web page in your browser: live counts, Plotly
charts, a Pandas records table, readability scores, a compare page,
and download buttons for the reports.

```
python3 -m venv venv
venv/bin/pip install -r requirements.txt
venv/bin/streamlit run app.py
```

(On Windows, use `venv\Scripts\pip` and `venv\Scripts\streamlit`.)
Then open the address it prints, usually http://localhost:8501.

The dashboard has five pages (left sidebar): **Analyze** (paste,
upload, or load a sample; press Ctrl+Enter to see the counts),
**Library** (search, filter, sort, open, delete), **Summary**
(totals, charts, exports), **Compare** (Jaccard + cosine similarity),
and **Import** (bulk CSV with a row-by-row error log).

One thing to know: in the text box, Streamlit only sends your text
when you press Ctrl+Enter or click outside the box. That is how
Streamlit works, not a bug.

## What each file does

- `run.py` — the starting point. Run this file.
- `textstats/engine.py` — the counting rules (words, characters,
  sentences, frequent words, reading time). This is the brain.
- `textstats/validate.py` — all the safety checks (empty text, wrong
  file type, file too big, top-N out of range).
- `textstats/storage.py` — saves and loads records (JSON + CSV).
  If the save file is missing it is created; if it is corrupt it is
  renamed to `records.json.bak` and a fresh one is started.
- `textstats/summary.py` — totals, averages, shortest/longest record,
  records per day, and a bar chart (needs matplotlib, optional).
- `textstats/exporters.py` — exports a Markdown report, a plain-text
  audit log, and a CSV report into `exports/`.
- `textstats/importer.py` — bulk import from CSV, with a row-by-row
  error log for bad rows.
- `textstats/cli.py` — the menu you see on screen.
- `app.py` — the Streamlit dashboard (needs `requirements.txt`).
- `textstats/nlp.py` — rule-based NLP: syllable counts, Flesch
  readability, Jaccard + cosine similarity, writing insights.
- `textstats/charts.py` — Plotly charts for the dashboard (top words,
  sentence lengths, analyses per day, records by source).
- `requirements.txt` — streamlit, plotly, pandas (dashboard only).
- `tests/test_nlp.py` — checks the NLP helpers.
- `tests/test_charts.py` — checks the Plotly chart builders.
- `data/` — your saved records (`records.json` + `records.csv`).
- `samples/` — 40 sample texts (`samples.csv` + `samples.json`),
  including edge cases (one word, numbers only, unicode text, one
  very long word, one word repeated until it dominates, one very long
  text, and one empty entry that is invalid on purpose).
- `exports/` — reports, charts and import error logs go here.
- `tests/test_engine.py` — checks that the counting is correct.

## The menu

1. Analyse pasted text — type text, finish with a line that says `END`.
2. Analyse a text file — give the path to a `.txt` or `.md` file.
3. View / search saved records — search by title, filter by source.
4. Executive summary — totals, averages, trends, and a chart.
5. Export — Markdown report, audit log, or CSV report.
6. Bulk import from CSV — the file needs `title` and `text` columns.
7. Load the sample dataset — analyses all 40 samples at once.
0. Exit.

## 5-minute demo (for your teacher)

1. **Launch** — run `python3 run.py`. Show the welcome screen.
2. **Add an entry** — pick `1`, paste a short text, type `END`,
   give it a title. Show the counts on screen.
3. **Show validation catching a bad input** — pick `1` again and
   press Enter on an empty line, or pick `2` and type a file path
   that does not exist. The app explains the problem and asks again
   instead of crashing.
4. **Show the summary** — pick `4`. Point at the totals, the
   average words per record, and the records-per-day chart.
5. **Prove saving works** — pick `0` to exit, run `python3 run.py`
   again, pick `3`. Your records are still there.
6. **Export** — pick `5`, choose `4` (all three). Open the
   Markdown report in the `exports/` folder.

## Counting rules (so the website matches exactly)

- Words: `text.split()` count.
- Characters: `len(text)`; without spaces: all whitespace removed first.
- Sentences: split on runs of `.` `!` `?`, drop empty pieces. Text
  with no terminator counts as 1 sentence; empty text counts as 0.
- Frequent words: lowercase each word, strip punctuation from both
  ends, drop empties. Top 10, sorted by count (high to low), then by
  word (A to Z).
- Reading time: words / 200 per minute.
