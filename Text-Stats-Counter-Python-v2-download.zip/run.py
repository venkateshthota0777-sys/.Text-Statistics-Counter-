#!/usr/bin/env python3
"""Entry point for Text Statistics Counter (Project #107).

Run with:  python3 run.py
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from textstats.cli import main

if __name__ == "__main__":
    main()
