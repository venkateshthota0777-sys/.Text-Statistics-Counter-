"""Defensive input validation (SRS sections 3 and 8).

Every check returns a plain (ok, message) style result instead of
raising, so the terminal interface can show a friendly message and ask
again. Nothing in this module ever crashes on bad input.
"""

from __future__ import annotations

import os

ALLOWED_EXTENSIONS = {".txt", ".md"}
WARN_SIZE_BYTES = 1 * 1024 * 1024      # warn over 1 MB
MAX_SIZE_BYTES = 5 * 1024 * 1024       # reject over 5 MB
TOP_N_MIN = 1
TOP_N_MAX = 20


def check_text(text: str) -> tuple[bool, str]:
    """Text must not be empty or whitespace-only."""
    if text is None or not str(text).strip():
        return False, "Text is empty. Please type or paste some text first."
    return True, ""


def check_title(title: str) -> tuple[bool, str]:
    """A record title must not be blank."""
    if title is None or not str(title).strip():
        return False, "Title is empty. Please give the text a short title."
    return True, ""


def check_file(path: str) -> tuple[bool, str, str]:
    """Check a file before analysing it.

    Returns (ok, error_message, warning_message).
    - file must exist and be a file
    - extension must be .txt or .md
    - over 1 MB: warning, still allowed
    - over 5 MB: rejected
    """
    if path is None or not str(path).strip():
        return False, "No file path given.", ""
    path = str(path).strip()
    if not os.path.exists(path):
        return False, f'File not found: "{path}". Check the path and try again.', ""
    if not os.path.isfile(path):
        return False, f'"{path}" is not a file.', ""
    _, ext = os.path.splitext(path)
    if ext.lower() not in ALLOWED_EXTENSIONS:
        return False, (
            f'Unsupported file type "{ext}". Only .txt and .md files '
            "are accepted."
        ), ""
    size = os.path.getsize(path)
    if size > MAX_SIZE_BYTES:
        return False, (
            f"File is too large ({size / (1024 * 1024):.1f} MB). "
            "Files over 5 MB are rejected."
        ), ""
    warning = ""
    if size > WARN_SIZE_BYTES:
        warning = (
            f"Warning: file is large ({size / (1024 * 1024):.1f} MB). "
            "Analysis may take a moment."
        )
    return True, "", warning


def read_text_file(path: str) -> tuple[bool, str, str]:
    """Read a text file as UTF-8 (unknown bytes become a placeholder).

    Returns (ok, text, error_message).
    """
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as handle:
            return True, handle.read(), ""
    except OSError as exc:
        return False, "", f"Could not read the file: {exc}"


def check_top_n(value) -> tuple[bool, int, str]:
    """Top-N for frequent words must be a whole number from 1 to 20."""
    try:
        number = int(str(value).strip())
    except (TypeError, ValueError):
        return False, 10, "Top-N must be a whole number (for example 10)."
    if number < TOP_N_MIN or number > TOP_N_MAX:
        return False, 10, (
            f"Top-N must be between {TOP_N_MIN} and {TOP_N_MAX}."
        )
    return True, number, ""


def check_csv_row(title, text) -> tuple[bool, str]:
    """Validate one bulk-import row (title + text columns)."""
    if title is None or not str(title).strip():
        return False, "missing or empty title"
    if text is None or not str(text).strip():
        return False, "missing or empty text"
    return True, ""
