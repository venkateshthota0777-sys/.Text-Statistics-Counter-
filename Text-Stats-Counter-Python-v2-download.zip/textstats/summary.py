"""Executive summary generation (SRS section 3).

Computes totals, averages, min/max records, the most frequent word
overall, counts by source and a records-per-day trend. Produces a
plain-text table, and a PNG bar chart when matplotlib is available
(otherwise it says so and never crashes).
"""

from __future__ import annotations

import os
from collections import Counter

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXPORTS_DIR = os.path.join(BASE_DIR, "exports")


def compute_summary(records: list[dict]) -> dict:
    """Aggregate statistics over all stored records."""
    summary = {
        "total_records": len(records),
        "total_words": 0,
        "total_chars": 0,
        "total_sentences": 0,
        "avg_words_per_record": 0,
        "avg_words_per_sentence": 0,
        "min_record": None,
        "max_record": None,
        "most_frequent_word": None,
        "most_frequent_word_count": 0,
        "by_source": {},
        "per_day": {},
    }
    if not records:
        return summary

    summary["total_words"] = sum(r.get("word_count", 0) for r in records)
    summary["total_chars"] = sum(r.get("char_count", 0) for r in records)
    summary["total_sentences"] = sum(r.get("sentence_count", 0) for r in records)
    summary["avg_words_per_record"] = round(
        summary["total_words"] / len(records), 1
    )
    if summary["total_sentences"]:
        summary["avg_words_per_sentence"] = round(
            summary["total_words"] / summary["total_sentences"], 1
        )
    summary["min_record"] = min(records, key=lambda r: r.get("word_count", 0))
    summary["max_record"] = max(records, key=lambda r: r.get("word_count", 0))

    # Most frequent word overall: add up the stored top-word lists.
    overall = Counter()
    for record in records:
        for item in record.get("top_words", []):
            overall[item["word"]] += item["count"]
    if overall:
        word, count = overall.most_common(1)[0]
        summary["most_frequent_word"] = word
        summary["most_frequent_word_count"] = count

    summary["by_source"] = dict(Counter(r.get("source", "?") for r in records))
    per_day = Counter(
        str(r.get("created_at", ""))[:10] for r in records
    )
    summary["per_day"] = dict(sorted(per_day.items()))
    return summary


def format_summary_text(summary: dict) -> str:
    """Plain-text summary table for the terminal."""
    lines = []
    lines.append("EXECUTIVE SUMMARY")
    lines.append("=" * 56)
    lines.append(f"Total records analysed : {summary['total_records']}")
    lines.append(f"Total words            : {summary['total_words']:,}")
    lines.append(f"Total characters       : {summary['total_chars']:,}")
    lines.append(f"Total sentences        : {summary['total_sentences']:,}")
    lines.append(f"Average words/record   : {summary['avg_words_per_record']}")
    lines.append(f"Average words/sentence : {summary['avg_words_per_sentence']}")
    if summary["most_frequent_word"]:
        lines.append(
            f"Most frequent word     : \"{summary['most_frequent_word']}\" "
            f"({summary['most_frequent_word_count']} times)"
        )
    if summary["min_record"] is not None:
        lines.append(
            f"Shortest record        : #{summary['min_record']['id']} "
            f"\"{summary['min_record']['title']}\" "
            f"({summary['min_record']['word_count']} words)"
        )
        lines.append(
            f"Longest record         : #{summary['max_record']['id']} "
            f"\"{summary['max_record']['title']}\" "
            f"({summary['max_record']['word_count']} words)"
        )
    lines.append("")
    lines.append("Records by source:")
    for source, count in sorted(summary["by_source"].items()):
        lines.append(f"  {source:<10} {count}")
    lines.append("")
    lines.append("Records per day:")
    if summary["per_day"]:
        for day, count in summary["per_day"].items():
            bar = "#" * min(count, 40)
            lines.append(f"  {day}  {count:<4} {bar}")
    else:
        lines.append("  (no records yet)")
    lines.append("=" * 56)
    return "\n".join(lines)


def make_chart(summary: dict, out_path: str | None = None) -> tuple[str | None, str]:
    """Bar chart of records per day. Returns (path or None, note)."""
    if not summary["per_day"]:
        return None, "No records yet, so there is nothing to chart."
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return None, (
            "Matplotlib is not installed, so the chart was skipped. "
            "Install it with: pip install matplotlib"
        )
    if out_path is None:
        os.makedirs(EXPORTS_DIR, exist_ok=True)
        out_path = os.path.join(EXPORTS_DIR, "summary_chart.png")
    days = list(summary["per_day"].keys())
    counts = list(summary["per_day"].values())
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.bar(days, counts, color="#2563eb")
    ax.set_title("Records per day")
    ax.set_xlabel("Date")
    ax.set_ylabel("Records")
    fig.tight_layout()
    fig.savefig(out_path)
    plt.close(fig)
    return out_path, ""
