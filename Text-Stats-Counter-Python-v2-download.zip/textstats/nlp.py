"""Rule-based NLP helpers: syllable counting, readability, similarity
and writing insights.

Pure standard library. These functions build on the verified counting
engine (textstats.engine) and never re-implement counting themselves.
No Streamlit import here, so the unit tests can import this module
without a web framework installed.
"""

from __future__ import annotations

import math
import re

import textstats.engine as engine

_VOWELS = set("aeiouy")


def count_syllables(word: str) -> int:
    """Rule-based syllable count for a single English word."""
    letters = re.sub(r"[^a-z]", "", word.lower())
    if not letters:
        return 0

    # Count groups of consecutive vowels (a e i o u y).
    groups = 0
    prev_vowel = False
    for ch in letters:
        is_vowel = ch in _VOWELS
        if is_vowel and not prev_vowel:
            groups += 1
        prev_vowel = is_vowel

    # Trailing silent "e" (but not the "-le" ending after a consonant,
    # as in "table" or "little").
    if groups > 1 and letters.endswith("e"):
        if not (len(letters) > 2 and letters[-2] not in _VOWELS
                and letters.endswith("le")):
            groups -= 1

    # Trailing "ed" is usually silent (as in "played") unless it
    # follows "t" or "d" (as in "wanted", "needed").
    if groups > 1 and letters.endswith("ed") and len(letters) > 2 \
            and letters[-3] not in "td":
        groups -= 1

    # Trailing "es" is usually silent (as in "makes") unless it makes
    # its own sound (as in "boxes", "watches", "classes").
    if groups > 1 and letters.endswith("es"):
        if letters[-3] not in "sxz" and not letters.endswith(("ches", "shes")):
            groups -= 1

    return max(1, groups)


def readability(text: str) -> dict:
    """Return Flesch reading ease, Flesch-Kincaid grade, syllables and
    words per sentence. Empty text scores 0.0 on both scales."""
    words = len(text.split())
    sentences = engine.count_sentences(text)
    tokens = engine.cleaned_tokens(text)
    syllables = sum(count_syllables(t) for t in tokens)

    if words == 0 or sentences == 0:
        return {
            "flesch_reading_ease": 0.0,
            "flesch_kincaid_grade": 0.0,
            "syllable_count": 0,
            "words_per_sentence": 0.0,
        }

    wps = words / sentences
    spw = syllables / words
    ease = 206.835 - 1.015 * wps - 84.6 * spw
    grade = 0.39 * wps + 11.8 * spw - 15.59

    return {
        "flesch_reading_ease": round(ease, 1),
        "flesch_kincaid_grade": round(grade, 1),
        "syllable_count": syllables,
        "words_per_sentence": round(wps, 1),
    }


def similarity(text_a: str, text_b: str) -> dict:
    """Return Jaccard and cosine similarity between two texts (0 to 1).

    Jaccard works on the sets of cleaned words; cosine works on the
    word-count vectors. Two empty texts count as identical (1.0).
    """
    tokens_a = engine.cleaned_tokens(text_a)
    tokens_b = engine.cleaned_tokens(text_b)

    if not tokens_a and not tokens_b:
        return {"jaccard": 1.0, "cosine": 1.0}
    if not tokens_a or not tokens_b:
        return {"jaccard": 0.0, "cosine": 0.0}

    set_a, set_b = set(tokens_a), set(tokens_b)
    jaccard = len(set_a & set_b) / len(set_a | set_b)

    counts_a = {}
    for t in tokens_a:
        counts_a[t] = counts_a.get(t, 0) + 1
    counts_b = {}
    for t in tokens_b:
        counts_b[t] = counts_b.get(t, 0) + 1

    dot = sum(counts_a[w] * counts_b.get(w, 0) for w in counts_a)
    norm_a = math.sqrt(sum(c * c for c in counts_a.values()))
    norm_b = math.sqrt(sum(c * c for c in counts_b.values()))
    cosine = dot / (norm_a * norm_b) if norm_a and norm_b else 0.0

    return {"jaccard": round(jaccard, 3), "cosine": round(cosine, 3)}


def writing_insights(analysis: dict) -> list:
    """Return plain-English insight strings for an analyze_text result."""
    insights = []
    word_count = analysis.get("word_count", 0)
    sentence_count = analysis.get("sentence_count", 0)
    reading_minutes = analysis.get("reading_minutes", 0.0)
    top_words = analysis.get("top_words", [])

    if word_count > 100000:
        insights.append("Very large text: over 100,000 words.")

    if top_words and word_count > 0 and top_words[0]["count"] / word_count > 0.30:
        word = top_words[0]["word"]
        pct = round(top_words[0]["count"] / word_count * 100, 1)
        insights.append(f'One word dominates: "{word}" is {pct}% of all words.')

    if sentence_count > 0 and word_count / sentence_count > 40:
        avg = round(word_count / sentence_count, 1)
        insights.append(f"Very long sentences: average {avg} words per sentence.")

    if reading_minutes > 60:
        insights.append(f"Long read: about {reading_minutes} minutes.")

    if 0 < word_count < 10:
        insights.append("Very short text: fewer than 10 words.")

    if sentence_count == 0 and word_count > 0:
        insights.append("No sentences found: add a full stop, question mark or exclamation mark.")

    return insights
