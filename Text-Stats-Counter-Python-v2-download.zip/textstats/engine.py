"""Core counting engine for Text Statistics Counter (Project #107).

Pure standard library. The counting rules in this file are the single
source of truth — any other front end (for example a website) must match
them exactly, so do not change a rule without updating the spec.

Rules (exactly as specified):
- words: text.split() count (split on any whitespace, drop empties).
- chars with spaces: len(text).
  chars without spaces: len(text with every whitespace char removed).
- sentences: split on runs of . ! ? (regex [.!?]+), strip each piece,
  drop empties; non-empty text with no terminator counts as 1;
  empty text counts as 0.
- frequent words: for each token, lowercase it, strip leading/trailing
  ASCII punctuation, drop if empty; count them; top N sorted by count
  desc then word asc.
- unique_words: number of different cleaned words.
- avg_word_length: sum of cleaned-word lengths / cleaned-word count,
  2 decimals, 0 when there are no words.
- longest_word: longest cleaned word; ties go to the first one seen.
- paragraphs: split on blank lines, strip, drop empties.
- reading time: words / 200 per minute, 1 decimal.
"""

from __future__ import annotations

import re
import string
from collections import Counter
from datetime import datetime

SENTENCE_SPLIT_RE = re.compile(r"[.!?]+")
PARAGRAPH_SPLIT_RE = re.compile(r"\r?\n\s*\r?\n")
DEFAULT_TOP_N = 10
WORDS_PER_MINUTE = 200


def clean_word(token: str) -> str:
    """Lowercase a token and strip leading/trailing ASCII punctuation."""
    return token.lower().strip(string.punctuation)


def cleaned_tokens(text: str) -> list[str]:
    """All words of the text, cleaned, in appearance order."""
    tokens = []
    for raw in text.split():
        cleaned = clean_word(raw)
        if cleaned:
            tokens.append(cleaned)
    return tokens


def count_sentences(text: str) -> int:
    """Sentence count per the spec.

    Split on runs of . ! ? , strip each piece, drop empties.
    Non-empty text with NO terminator at all counts as 1 sentence;
    empty text counts as 0. Text made only of terminators (for
    example "!!!") has no sentence content, so it counts as 0.
    """
    if not text.strip():
        return 0
    if not SENTENCE_SPLIT_RE.search(text):
        return 1
    pieces = [p.strip() for p in SENTENCE_SPLIT_RE.split(text)]
    return len([p for p in pieces if p])


def count_paragraphs(text: str) -> int:
    """Paragraph count: blocks separated by blank lines."""
    if not text.strip():
        return 0
    parts = [p.strip() for p in PARAGRAPH_SPLIT_RE.split(text)]
    return len([p for p in parts if p])


def top_words(tokens: list[str], n: int = DEFAULT_TOP_N) -> list[dict]:
    """Top n words, sorted by count desc, then word asc."""
    counts = Counter(tokens)
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return [{"word": word, "count": count} for word, count in ordered[:n]]


def analyze_text(text: str, top_n: int = DEFAULT_TOP_N) -> dict:
    """Analyse a text and return every statistic.

    This returns the full stats dict (including longest_word). Use
    make_record() to build the exact record that gets stored.
    """
    tokens = cleaned_tokens(text)
    word_count = len(text.split())
    sentence_count = count_sentences(text)

    if tokens:
        avg_word_length = round(sum(len(w) for w in tokens) / len(tokens), 2)
        longest_word = tokens[0]
        for token in tokens[1:]:
            if len(token) > len(longest_word):  # strict > keeps first on ties
                longest_word = token
    else:
        avg_word_length = 0
        longest_word = ""

    stats = {
        "char_count": len(text),
        "char_no_space": len("".join(text.split())),
        "word_count": word_count,
        "sentence_count": sentence_count,
        "paragraph_count": count_paragraphs(text),
        "unique_words": len(set(tokens)),
        "avg_word_length": avg_word_length,
        "longest_word": longest_word,
        "reading_minutes": round(word_count / WORDS_PER_MINUTE, 1),
        "top_words": top_words(tokens, top_n),
    }
    return stats


def make_record(text: str, title: str, source: str,
                top_n: int = DEFAULT_TOP_N) -> dict:
    """Build the exact record that is stored (fields per the spec)."""
    stats = analyze_text(text, top_n=top_n)
    return {
        "id": 0,  # storage assigns the real id when saving
        "title": title,
        "source": source,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "char_count": stats["char_count"],
        "char_no_space": stats["char_no_space"],
        "word_count": stats["word_count"],
        "sentence_count": stats["sentence_count"],
        "paragraph_count": stats["paragraph_count"],
        "unique_words": stats["unique_words"],
        "avg_word_length": stats["avg_word_length"],
        "reading_minutes": stats["reading_minutes"],
        "top_words": stats["top_words"],
    }


def threshold_warnings(stats: dict) -> list[str]:
    """Warning flags for unusual texts (stretch feature, SRS section 4)."""
    warnings = []
    words = stats["word_count"]
    if words > 100_000:
        warnings.append("Very large text: over 100,000 words.")
    if stats["top_words"] and words > 0:
        top = stats["top_words"][0]
        if top["count"] / words > 0.30:
            warnings.append(
                f'One word dominates: "{top["word"]}" is '
                f"{round(top['count'] / words * 100, 1)}% of all words."
            )
    sentences = stats["sentence_count"]
    if sentences > 0 and words / sentences > 40:
        warnings.append(
            f"Very long sentences: average {round(words / sentences, 1)} "
            "words per sentence."
        )
    if stats["reading_minutes"] > 60:
        warnings.append(
            f"Long read: about {stats['reading_minutes']} minutes."
        )
    return warnings
