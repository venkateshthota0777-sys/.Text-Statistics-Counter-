"""Interactive terminal interface (SRS sections 3, 6 and 9).

Menu-driven, with ANSI colours and a branded welcome screen.
The golden rule of this file: the program NEVER crashes on bad input.
Every prompt goes through ask(), which loops until the answer is valid.
"""

from __future__ import annotations

import os
import sys

from textstats import engine, exporters, importer, storage, summary, validate

# --- ANSI colours -------------------------------------------------------
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
RED = "\033[31m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
BLUE = "\033[34m"
CYAN = "\033[36m"

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SAMPLES_CSV = os.path.join(BASE_DIR, "samples", "samples.csv")

PAGE_SIZE = 10


def colour(text: str, code: str) -> str:
    return f"{code}{text}{RESET}"


def banner() -> None:
    print()
    print(colour("=" * 60, CYAN))
    print(colour("   TEXT STATISTICS COUNTER", BOLD + CYAN))
    print(colour("   Count words, characters, sentences & frequent words",
                 DIM))
    print(colour("   Project #107  |  Digital Tools & Productivity", DIM))
    print(colour("=" * 60, CYAN))
    print()


# --- central input wrapper: loops until the input is valid -------------
def ask(prompt: str, validator=None, allow_empty: bool = False):
    """Ask for input until it passes validator (or the user quits).

    validator(value) must return (ok, parsed_value_or_None, message).
    With no validator, any non-empty line is accepted (unless
    allow_empty is True). Ctrl+C / Ctrl+D exits cleanly, never crashes.
    """
    while True:
        try:
            value = input(colour(prompt, BOLD))
        except (EOFError, KeyboardInterrupt):
            print()
            print(colour("Goodbye! Your records are saved.", GREEN))
            raise SystemExit(0)
        if validator is None:
            if value.strip() or allow_empty:
                return value
            print(colour("  That was empty. Please type something.", YELLOW))
            continue
        ok, parsed, message = validator(value)
        if ok:
            return parsed
        print(colour(f"  {message}", RED))


def ask_menu_choice() -> str:
    def _check(value):
        value = value.strip()
        if value in {"0", "1", "2", "3", "4", "5", "6", "7"}:
            return True, value, ""
        return False, None, "Please choose a number from the menu (0-7)."

    return ask("Choose an option (0-7): ", _check)


def ask_top_n() -> int:
    def _check(value):
        if value.strip() == "":
            return True, 10, ""  # Enter = default 10
        return validate.check_top_n(value)

    return ask("How many top words to show? (1-20, Enter = 10): ", _check)


def show_menu() -> None:
    print(colour("What would you like to do?", BOLD))
    print("  1. Analyse pasted text")
    print("  2. Analyse a text file (.txt / .md)")
    print("  3. View / search saved records")
    print("  4. Executive summary")
    print("  5. Export (Markdown / audit log / CSV)")
    print("  6. Bulk import from CSV")
    print("  7. Load the sample dataset (40 entries)")
    print("  0. Exit")
    print()


# --- shared helpers ------------------------------------------------------
def show_result(record: dict, stats: dict) -> None:
    print()
    print(colour("RESULT", BOLD + GREEN))
    print("-" * 56)
    print(f"  Title            : {record['title']}")
    print(f"  Characters       : {stats['char_count']:,}"
          f"  (without spaces: {stats['char_no_space']:,})")
    print(f"  Words            : {stats['word_count']:,}")
    print(f"  Sentences        : {stats['sentence_count']}")
    print(f"  Paragraphs       : {stats['paragraph_count']}")
    print(f"  Unique words     : {stats['unique_words']}")
    print(f"  Avg word length  : {stats['avg_word_length']}")
    print(f"  Longest word     : {stats['longest_word'] or '-'}")
    print(f"  Reading time     : {stats['reading_minutes']} min")
    top_text = ", ".join(
        f"{w['word']} ({w['count']})" for w in stats["top_words"]
    ) or "-"
    print(f"  Top words        : {top_text}")
    print("-" * 56)
    warnings = engine.threshold_warnings(stats)
    for warning in warnings:
        print(colour(f"  ! {warning}", YELLOW))
    if warnings:
        print("-" * 56)


def analyse_and_save(text: str, title: str, source: str) -> None:
    top_n = ask_top_n()
    stats = engine.analyze_text(text, top_n=top_n)
    record = engine.make_record(text, title, source, top_n=top_n)
    record, notices = storage.add_record(record)
    for notice in notices:
        print(colour(f"  Note: {notice}", YELLOW))
    show_result(record, stats)
    print(colour(f"  Saved as record #{record['id']}.", GREEN))
    print()


# --- menu actions --------------------------------------------------------
def action_paste() -> None:
    print(colour("\n— Analyse pasted text —", BOLD))
    print("Type or paste your text. Finish with a line that says only END.")
    lines = []
    while True:
        try:
            line = input()
        except (EOFError, KeyboardInterrupt):
            print()
            print(colour("Goodbye! Your records are saved.", GREEN))
            raise SystemExit(0)
        if line.strip() == "END":
            break
        lines.append(line)
    text = "\n".join(lines)
    ok, message = validate.check_text(text)
    if not ok:
        print(colour(f"  {message}", RED))
        print(colour("  Nothing was saved. Try option 1 again.", YELLOW))
        return
    def _title_check(value):
        ok, message = validate.check_title(value)
        return ok, value.strip() if ok else None, message

    title = ask("Title for this text: ", _title_check)
    analyse_and_save(text, title, source="paste")


def action_file() -> None:
    print(colour("\n— Analyse a text file —", BOLD))
    while True:
        path = ask("Path to a .txt or .md file: ")
        ok, error, warning = validate.check_file(path)
        if not ok:
            print(colour(f"  {error}", RED))
            again = ask("Try another file? (y/n): ",
                        lambda v: (v.strip().lower() in {"y", "n"},
                                   v.strip().lower(), "Please type y or n."))
            if again == "n":
                return
            continue
        if warning:
            print(colour(f"  {warning}", YELLOW))
        break
    ok, text, error = validate.read_text_file(path)
    if not ok:
        print(colour(f"  {error}", RED))
        return
    ok, message = validate.check_text(text)
    if not ok:
        print(colour(f"  {message}", RED))
        return
    default_title = os.path.splitext(os.path.basename(path))[0]
    title = ask(f"Title [{default_title}]: ",
                lambda v: (True, v.strip() or default_title, ""))
    analyse_and_save(text, title, source="file")


def action_view() -> None:
    print(colour("\n— Saved records —", BOLD))
    records, notices = storage.load_records()
    for notice in notices:
        print(colour(f"  Note: {notice}", YELLOW))
    if not records:
        print("  No records yet. Analyse a text first (option 1 or 2).")
        return
    keyword = ask("Search by title keyword (Enter = show all): ",
                  lambda v: (True, v.strip(), ""), allow_empty=True)
    source = ask("Filter by source — paste/file/sample/import "
                 "(Enter = all): ",
                 lambda v: (True, v.strip().lower(), ""), allow_empty=True)
    found = storage.search_records(records, keyword=keyword, source=source)
    if not found:
        print(colour("  Nothing matched that search.", YELLOW))
        return
    print(f"  {len(found)} record(s) found:\n")
    print(f"  {'ID':>3}  {'Title':<28} {'Src':<7} {'Words':>6}  "
          f"{'Sents':>5}  Top word")
    print("  " + "-" * 70)
    page = 0
    while page * PAGE_SIZE < len(found):
        for record in found[page * PAGE_SIZE:(page + 1) * PAGE_SIZE]:
            top = record.get("top_words", [])
            top_text = f"{top[0]['word']} ({top[0]['count']})" if top else "-"
            print(f"  {record.get('id', ''):>3}  "
                  f"{str(record.get('title', ''))[:28]:<28} "
                  f"{str(record.get('source', ''))[:7]:<7} "
                  f"{record.get('word_count', 0):>6}  "
                  f"{record.get('sentence_count', 0):>5}  {top_text}")
        page += 1
        if page * PAGE_SIZE < len(found):
            more = ask("  Show next 10? (y/n): ",
                       lambda v: (v.strip().lower() in {"y", "n"},
                                  v.strip().lower(),
                                  "Please type y or n."))
            if more == "n":
                break
    print()


def action_summary() -> None:
    print(colour("\n— Executive summary —", BOLD))
    records, notices = storage.load_records()
    for notice in notices:
        print(colour(f"  Note: {notice}", YELLOW))
    if not records:
        print("  No records yet. Analyse a text first (option 1 or 2).")
        return
    summ = summary.compute_summary(records)
    print(summary.format_summary_text(summ))
    chart_path, note = summary.make_chart(summ)
    if chart_path:
        print(colour(f"  Chart saved to: {chart_path}", GREEN))
    elif note:
        print(colour(f"  Note: {note}", YELLOW))
    print()


def action_export() -> None:
    print(colour("\n— Export —", BOLD))
    records, notices = storage.load_records()
    for notice in notices:
        print(colour(f"  Note: {notice}", YELLOW))
    if not records:
        print("  No records yet. Nothing to export.")
        return
    print("  1. Markdown report (.md)")
    print("  2. Plain-text audit log (.txt)")
    print("  3. CSV report (.csv)")
    print("  4. All three")
    choice = ask("Choose a format (1-4): ",
                 lambda v: (v.strip() in {"1", "2", "3", "4"}, v.strip(),
                            "Please choose 1, 2, 3 or 4."))
    summ = summary.compute_summary(records)
    made = []
    if choice in {"1", "4"}:
        made.append(exporters.export_markdown(records, summ))
    if choice in {"2", "4"}:
        made.append(exporters.export_audit_log(records))
    if choice in {"3", "4"}:
        made.append(exporters.export_csv_report(records))
    for path in made:
        print(colour(f"  Saved: {path}", GREEN))
    print()


def action_import() -> None:
    print(colour("\n— Bulk import from CSV —", BOLD))
    print("The CSV needs a header with 'title' and 'text' columns.")
    path = ask("Path to the CSV file: ")
    if not os.path.exists(path):
        print(colour(f'  File not found: "{path}".', RED))
        return
    result = importer.import_csv(path, storage.add_record)
    print()
    print(f"  Imported: {result['imported']} row(s)")
    print(f"  Skipped : {result['skipped']} row(s)")
    if result["error_log_path"]:
        print(colour(f"  Error log: {result['error_log_path']}", YELLOW))
        for row_number, reason in result["errors"][:10]:
            print(f"    Row {row_number}: {reason}")
        if len(result["errors"]) > 10:
            print(f"    ... and {len(result['errors']) - 10} more "
                  "(see the error log)")
    print()


def action_samples() -> None:
    print(colour("\n— Load the sample dataset —", BOLD))
    if not os.path.exists(SAMPLES_CSV):
        print(colour("  samples/samples.csv was not found.", RED))
        return
    print("  This analyses all 40 sample entries (one is invalid on "
          "purpose, to show the error log).")
    result = importer.import_csv(SAMPLES_CSV, storage.add_record)
    print()
    print(f"  Imported: {result['imported']} sample(s)")
    print(f"  Skipped : {result['skipped']} sample(s)")
    if result["error_log_path"]:
        print(colour(f"  Error log: {result['error_log_path']}", YELLOW))
        for row_number, reason in result["errors"]:
            print(f"    Row {row_number}: {reason}")
    print()


ACTIONS = {
    "1": action_paste,
    "2": action_file,
    "3": action_view,
    "4": action_summary,
    "5": action_export,
    "6": action_import,
    "7": action_samples,
}


def main() -> None:
    banner()
    _, notices = storage.load_records()
    for notice in notices:
        print(colour(f"  Note: {notice}", YELLOW))
    while True:
        show_menu()
        choice = ask_menu_choice()
        if choice == "0":
            print(colour("\nGoodbye! Your records are saved.", GREEN))
            return
        action = ACTIONS[choice]
        try:
            action()
        except SystemExit:
            raise
        except Exception as exc:  # a bug must never kill the demo
            print(colour(f"\n  Something went wrong: {exc}", RED))
            print(colour("  Nothing was lost — your records are still "
                         "saved. Try again.\n", YELLOW))


if __name__ == "__main__":
    main()
