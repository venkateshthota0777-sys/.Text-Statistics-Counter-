"""Plotly chart builders for the Streamlit dashboard.

Pure functions (no Streamlit import) so unit tests can check the
figures without a browser. Every chart uses the verified counting
engine — nothing here re-implements counting.
"""

from __future__ import annotations

import re
from datetime import date, timedelta

import plotly.express as px
import plotly.graph_objects as go

import textstats.engine as engine  # noqa: F401  (kept for the shared rule)

SENTENCE_SPLIT_RE = re.compile(r"[.!?]+")


def top_words_bar(analysis: dict):
    """Horizontal bar chart of the top-10 frequent words."""
    top = analysis.get("top_words", [])
    if not top:
        fig = go.Figure()
        fig.update_layout(
            title="Most frequent words",
            xaxis_title="Count",
            yaxis_title="Word",
        )
        return fig
    words = [item["word"] for item in top][::-1]
    counts = [item["count"] for item in top][::-1]
    fig = px.bar(
        x=counts,
        y=words,
        orientation="h",
        labels={"x": "Count", "y": "Word"},
        title="Most frequent words",
    )
    fig.update_layout(showlegend=False)
    return fig


def sentence_lengths(text: str) -> list[int]:
    """Word count of each sentence, using the engine's sentence rule.

    Same split as the engine ([.!?]+), empty pieces dropped, so the
    histogram always agrees with the sentence count.
    """
    if not text.strip():
        return []
    pieces = [piece.strip() for piece in SENTENCE_SPLIT_RE.split(text)]
    return [len(piece.split()) for piece in pieces if piece]


def sentence_length_hist(text: str):
    """Histogram of words per sentence."""
    lengths = sentence_lengths(text)
    if not lengths:
        fig = go.Figure()
        fig.update_layout(
            title="Words per sentence",
            xaxis_title="Words",
            yaxis_title="Sentences",
        )
        return fig
    bins = max(1, min(10, len(set(lengths))))
    fig = px.histogram(
        x=lengths,
        nbins=bins,
        labels={"x": "Words per sentence", "y": "Sentences"},
        title="Words per sentence",
    )
    return fig


def per_day_line(per_day: dict, days: int = 14):
    """Line chart of analyses per day over the last `days` days.

    Missing days are filled with 0, so the line always covers the
    full window even when nothing was saved on a day.
    """
    today = date.today()
    dates = [
        (today - timedelta(days=i)).isoformat()
        for i in range(days - 1, -1, -1)
    ]
    counts = [int(per_day.get(day, 0)) for day in dates]
    fig = px.line(
        x=dates,
        y=counts,
        markers=True,
        labels={"x": "Date", "y": "Analyses"},
        title="Analyses per day (last 14 days)",
    )
    fig.update_layout(yaxis=dict(dtick=1))
    return fig


def by_source_bar(by_source: dict):
    """Bar chart of how many records came from each source."""
    if not by_source:
        fig = go.Figure()
        fig.update_layout(
            title="Records by source",
            xaxis_title="Source",
            yaxis_title="Records",
        )
        return fig
    sources = sorted(by_source)
    counts = [int(by_source[source]) for source in sources]
    fig = px.bar(
        x=sources,
        y=counts,
        labels={"x": "Source", "y": "Records"},
        title="Records by source",
    )
    fig.update_layout(showlegend=False)
    return fig
