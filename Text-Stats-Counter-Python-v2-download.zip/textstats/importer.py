"""Bulk dataset import (SRS section 4, stretch feature).

Reads a CSV file with a header that has `title` and `text` columns.
Every row is validated; valid rows are analysed and saved, bad rows are
skipped and listed in a row-by-row error log (row number + reason).
"""

from __future__ import annotations

import csv
import os
from datetime import datetime

from textstats import validate
from textstats.engine import make_record

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXPORTS_DIR = os.path.join(BASE_DIR, "exports")


def import_csv(path: str, save_record) -> dict:
    """Import a CSV file. save_record is storage.add_record.

    Returns a dict with imported/skipped counts, the error list and the
    error-log file path ("" when there were no errors).
    """
    result = {
        "imported": 0, "skipped": 0,
        "errors": [], "error_log_path": "",
    }
    try:
        handle = open(path, "r", encoding="utf-8", newline="")
    except OSError as exc:
        result["errors"].append((0, f"could not open file: {exc}"))
        result["skipped"] = 1
        return result

    with handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            result["errors"].append((1, "file is empty, no header row found"))
            result["skipped"] = 1
            return result
        headers = [h.strip().lower() for h in reader.fieldnames if h]
        if "title" not in headers or "text" not in headers:
            result["errors"].append(
                (1, "header must have 'title' and 'text' columns, "
                    f"found: {', '.join(reader.fieldnames)}")
            )
            result["skipped"] = 1
            return result

        for row_number, row in enumerate(reader, start=2):
            title = (row.get("title") or "").strip()
            # tolerate a capitalised header too
            if title == "" and row.get("Title"):
                title = str(row.get("Title")).strip()
            text = row.get("text") or row.get("Text") or ""
            ok, reason = validate.check_csv_row(title, text)
            if not ok:
                result["errors"].append((row_number, reason))
                result["skipped"] += 1
                continue
            try:
                record = make_record(text, title, source="import")
                save_record(record)
                result["imported"] += 1
            except Exception as exc:  # one bad row must never stop the import
                result["errors"].append(
                    (row_number, f"unexpected error: {exc}")
                )
                result["skipped"] += 1

    if result["errors"]:
        os.makedirs(EXPORTS_DIR, exist_ok=True)
        log_path = os.path.join(
            EXPORTS_DIR,
            "import_errors_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".txt",
        )
        with open(log_path, "w", encoding="utf-8") as log:
            log.write("BULK IMPORT — ROW-BY-ROW ERROR LOG\n")
            log.write(f"Source file: {path}\n")
            log.write(f"Imported: {result['imported']}, "
                      f"skipped: {result['skipped']}\n")
            log.write("-" * 50 + "\n")
            for row_number, reason in result["errors"]:
                log.write(f"Row {row_number}: {reason}\n")
        result["error_log_path"] = log_path
    return result
