"""Multi-format summary export (SRS section 4, stretch feature).

Writes timestamped files into exports/:
- Markdown report (.md)
- plain-text audit log (.txt)
- CSV report (.csv)
"""

from __future__ import annotations

import csv
import os
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXPORTS_DIR = os.path.join(BASE_DIR, "exports")

CSV_FIELDS = [
    "id", "title", "source", "created_at",
    "char_count", "char_no_space", "word_count", "sentence_count",
    "paragraph_count", "unique_words", "avg_word_length",
    "reading_minutes", "top_words",
]


def _timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _top_words_text(top_words: list[dict]) -> str:
    return ", ".join(f"{item['word']} ({item['count']})" for item in top_words)


def export_markdown(records: list[dict], summary: dict,
                    out_path: str | None = None) -> str:
    """Structured Markdown report."""
    os.makedirs(EXPORTS_DIR, exist_ok=True)
    if out_path is None:
        out_path = os.path.join(EXPORTS_DIR, f"report_{_timestamp()}.md")
    lines = [
        "# Text Statistics Counter — Summary Report",
        "",
        f"Generated: {datetime.now().isoformat(timespec='seconds')}",
        f"Total records: {summary['total_records']}",
        "",
        "## Totals",
        "",
        f"- Total words: {summary['total_words']:,}",
        f"- Total characters: {summary['total_chars']:,}",
        f"- Total sentences: {summary['total_sentences']:,}",
        f"- Average words per record: {summary['avg_words_per_record']}",
        f"- Average words per sentence: {summary['avg_words_per_sentence']}",
    ]
    if summary["most_frequent_word"]:
        lines.append(
            f"- Most frequent word: \"{summary['most_frequent_word']}\" "
            f"({summary['most_frequent_word_count']} times)"
        )
    lines += ["", "## Records", ""]
    lines.append("| ID | Title | Source | Words | Sentences | Top word |")
    lines.append("|---:|-------|--------|------:|----------:|----------|")
    for record in records:
        top = record.get("top_words", [])
        top_text = f"{top[0]['word']} ({top[0]['count']})" if top else "-"
        lines.append(
            f"| {record.get('id', '')} | {record.get('title', '')} | "
            f"{record.get('source', '')} | {record.get('word_count', 0)} | "
            f"{record.get('sentence_count', 0)} | {top_text} |"
        )
    lines.append("")
    with open(out_path, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines))
    return out_path


def export_audit_log(records: list[dict], out_path: str | None = None) -> str:
    """Plain-text audit log: one line per record, oldest first."""
    os.makedirs(EXPORTS_DIR, exist_ok=True)
    if out_path is None:
        out_path = os.path.join(EXPORTS_DIR, f"audit_log_{_timestamp()}.txt")
    lines = [
        "TEXT STATISTICS COUNTER — AUDIT LOG",
        f"Generated: {datetime.now().isoformat(timespec='seconds')}",
        f"Records: {len(records)}",
        "-" * 60,
    ]
    for record in records:
        lines.append(
            f"[{record.get('created_at', '')}] "
            f"#{record.get('id', '')} \"{record.get('title', '')}\" "
            f"({record.get('source', '')}) — "
            f"{record.get('word_count', 0)} words, "
            f"{record.get('char_count', 0)} chars, "
            f"{record.get('sentence_count', 0)} sentences. "
            f"Top words: {_top_words_text(record.get('top_words', []))}"
        )
    with open(out_path, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")
    return out_path


def export_csv_report(records: list[dict], out_path: str | None = None) -> str:
    """Standardised CSV report of all records."""
    os.makedirs(EXPORTS_DIR, exist_ok=True)
    if out_path is None:
        out_path = os.path.join(EXPORTS_DIR, f"report_{_timestamp()}.csv")
    with open(out_path, "w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS)
        writer.writeheader()
        for record in records:
            row = {field: record.get(field, "") for field in CSV_FIELDS}
            row["top_words"] = "; ".join(
                f"{item['word']}:{item['count']}"
                for item in record.get("top_words", [])
            )
            writer.writerow(row)
    return out_path
