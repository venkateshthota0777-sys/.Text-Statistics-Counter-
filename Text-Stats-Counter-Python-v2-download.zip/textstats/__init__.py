"""Text Statistics Counter — Project #107.

Beginner-friendly Python app (standard library only) that counts words,
characters, sentences and frequent words in a text file, saves every
analysis locally (JSON + CSV), and can search, summarise and export them.
"""

from textstats.engine import analyze_text, make_record

__all__ = ["analyze_text", "make_record"]
__version__ = "1.0.0"
