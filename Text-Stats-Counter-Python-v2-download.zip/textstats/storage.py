"""Local data persistence (SRS sections 3 and 8).

Records live in data/records.json (source of truth) and are mirrored to
data/records.csv. The JSON file carries schema_version 1.

Resilience rules (exactly as the SRS demands):
- missing file  -> create a clean, empty one.
- corrupt JSON  -> rename the broken file to records.json.bak, tell the
  user, and start fresh. Nothing is ever silently deleted.
- corrupt CSV   -> rebuild it from the JSON file.
"""

from __future__ import annotations

import csv
import json
import os

SCHEMA_VERSION = 1

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
JSON_PATH = os.path.join(DATA_DIR, "records.json")
CSV_PATH = os.path.join(DATA_DIR, "records.csv")
BACKUP_PATH = JSON_PATH + ".bak"

CSV_FIELDS = [
    "id", "title", "source", "created_at",
    "char_count", "char_no_space", "word_count", "sentence_count",
    "paragraph_count", "unique_words", "avg_word_length",
    "reading_minutes", "top_words",
]


def _top_words_to_csv(top_words: list[dict]) -> str:
    return "; ".join(f"{item['word']}:{item['count']}" for item in top_words)


def _record_to_csv_row(record: dict) -> dict:
    row = {field: record.get(field, "") for field in CSV_FIELDS}
    row["top_words"] = _top_words_to_csv(record.get("top_words", []))
    return row


def load_records() -> tuple[list[dict], list[str]]:
    """Load all records. Returns (records, notices for the user)."""
    notices: list[str] = []
    os.makedirs(DATA_DIR, exist_ok=True)

    if not os.path.exists(JSON_PATH):
        save_records([])
        notices.append("No saved records found. Created a fresh records file.")
        return [], notices

    try:
        with open(JSON_PATH, "r", encoding="utf-8") as handle:
            data = json.load(handle)
    except json.JSONDecodeError:
        os.replace(JSON_PATH, BACKUP_PATH)
        save_records([])
        notices.append(
            "Your records file was corrupt, so it was renamed to "
            "records.json.bak and a fresh file was started. "
            "Your old file was NOT deleted."
        )
        return [], notices
    except OSError as exc:
        notices.append(f"Could not read the records file: {exc}")
        return [], notices

    if isinstance(data, dict):
        records = data.get("records", [])
    elif isinstance(data, list):  # tolerate a bare list from older runs
        records = data
    else:
        records = []
    if not isinstance(records, list):
        records = []

    # Keep the CSV mirror in sync (rebuild it if it is missing/corrupt).
    try:
        _write_csv(records)
    except OSError as exc:
        notices.append(f"Could not update the CSV mirror: {exc}")
    return records, notices


def save_records(records: list[dict]) -> None:
    """Write records to JSON and mirror them to CSV."""
    os.makedirs(DATA_DIR, exist_ok=True)
    payload = {"schema_version": SCHEMA_VERSION, "records": records}
    with open(JSON_PATH, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, ensure_ascii=False)
    _write_csv(records)


def _write_csv(records: list[dict]) -> None:
    with open(CSV_PATH, "w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS)
        writer.writeheader()
        for record in records:
            writer.writerow(_record_to_csv_row(record))


def next_id(records: list[dict]) -> int:
    """Next record id (1 more than the highest id so far)."""
    return max((int(r.get("id", 0)) for r in records), default=0) + 1


def add_record(record: dict) -> tuple[dict, list[str]]:
    """Save a new record, assign its id, return (record, notices)."""
    records, notices = load_records()
    record["id"] = next_id(records)
    records.append(record)
    save_records(records)
    return record, notices


def search_records(records: list[dict], keyword: str = "",
                   source: str = "") -> list[dict]:
    """Keyword search in titles + filter by source (paste/file/sample/import)."""
    keyword = (keyword or "").strip().lower()
    source = (source or "").strip().lower()
    found = []
    for record in records:
        if keyword and keyword not in str(record.get("title", "")).lower():
            continue
        if source and str(record.get("source", "")).lower() != source:
            continue
        found.append(record)
    return found
