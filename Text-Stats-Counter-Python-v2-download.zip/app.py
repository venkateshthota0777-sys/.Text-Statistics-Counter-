"""Text Statistics Counter — Streamlit dashboard (Project #107).

Run with:  streamlit run app.py
(First create the venv and install the requirements, see README.md.)

The counting rules live in textstats.engine — this file never counts
anything itself, it only shows what the engine returns. Records are
stored in data/records.json (+ a CSV mirror), exactly like the CLI,
so the dashboard and the terminal app share the same library.
"""

from __future__ import annotations

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import pandas as pd
import streamlit as st

from textstats import charts, exporters, importer, nlp, storage, summary
from textstats.engine import (
    analyze_text,
    cleaned_tokens,
    make_record,
    threshold_warnings,
)

SAMPLES_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "samples", "samples.json"
)

st.set_page_config(
    page_title="Text Statistics Counter",
    page_icon="📝",
    layout="wide",
)

# ---------------------------------------------------------------- state
# The textarea widget (key "text_input") is the single source of truth
# for the current text. Sample/file buttons write to that key and rerun.
if "source" not in st.session_state:
    st.session_state.source = "paste"
if "selected_record_id" not in st.session_state:
    st.session_state.selected_record_id = None
if "last_upload" not in st.session_state:
    st.session_state.last_upload = None
if "last_sample" not in st.session_state:
    st.session_state.last_sample = None


def load_samples() -> list[dict]:
    """The built-in sample texts (40 entries, incl. edge cases)."""
    try:
        with open(SAMPLES_PATH, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, list) else []
    except (OSError, json.JSONDecodeError):
        return []


def title_from(text: str) -> str:
    """First few words of the text, for the record title."""
    words = text.strip().split()
    if not words:
        return "Untitled text"
    title = " ".join(words[:6])
    return title if len(title) <= 48 else title[:48] + "…"


def records_frame(records: list[dict]) -> pd.DataFrame:
    """Records as a Pandas table for the library view."""
    rows = []
    for record in records:
        top = record.get("top_words", [])
        rows.append(
            {
                "ID": record.get("id", ""),
                "Title": record.get("title", ""),
                "Source": record.get("source", ""),
                "Date": str(record.get("created_at", ""))[:10],
                "Words": record.get("word_count", 0),
                "Chars": record.get("char_count", 0),
                "Sentences": record.get("sentence_count", 0),
                "Reading (min)": record.get("reading_minutes", 0),
                "Top word": f"{top[0]['word']} ({top[0]['count']})" if top else "-",
            }
        )
    return pd.DataFrame(rows)


# ---------------------------------------------------------------- data
records, notices = storage.load_records()
for notice in notices:
    st.info(notice)
samples = load_samples()

st.sidebar.title("📝 Text Statistics Counter")
st.sidebar.caption("Project #107 — counts words, characters, sentences and frequent words.")
page = st.sidebar.radio(
    "Go to",
    ["Analyze", "Library", "Summary", "Compare", "Import"],
)

# ================================================================ ANALYZE
if page == "Analyze":
    st.header("Analyze a text")
    st.write("Paste text, upload a file, or load a sample. Then press Ctrl+Enter (or click outside the box) to see the counts.")

    col_input, col_load = st.columns([3, 1])
    with col_input:
        st.text_area(
            "Your text",
            height=220,
            key="text_input",
            placeholder="Paste your text here…",
        )
    with col_load:
        uploaded = st.file_uploader(
            "Or upload a file", type=["txt", "md"],
            help=".txt and .md only. Warns over 1 MB, refuses over 5 MB.",
        )
        if uploaded is not None and uploaded.name != st.session_state.last_upload:
            size = uploaded.size
            if size > 5 * 1024 * 1024:
                st.error("That file is over 5 MB — too big.")
            else:
                if size > 1024 * 1024:
                    st.warning("Heads up — that file is over 1 MB.")
                st.session_state.text_input = uploaded.read().decode(
                    "utf-8", errors="replace"
                )
                st.session_state.source = "file"
                st.session_state.last_upload = uploaded.name
                st.rerun()
        sample_titles = ["— pick a sample —"] + [s.get("title", "?") for s in samples]
        picked = st.selectbox(
            "Or load a sample", sample_titles, key="sample_pick"
        )
        if picked != "— pick a sample —" and picked != st.session_state.last_sample:
            chosen = samples[sample_titles.index(picked) - 1]
            st.session_state.text_input = chosen.get("text", "")
            st.session_state.source = "sample"
            st.session_state.last_sample = picked
            st.session_state.sample_pick = "— pick a sample —"
            st.rerun()

    text = st.session_state.get("text_input", "") or ""
    if not text.strip():
        st.info("Type or paste some text to see its statistics.")
    else:
        stats = analyze_text(text)
        row = st.columns(5)
        row[0].metric("Words", f"{stats['word_count']:,}")
        row[1].metric("Characters", f"{stats['char_count']:,}")
        row[2].metric("Without spaces", f"{stats['char_no_space']:,}")
        row[3].metric("Sentences", f"{stats['sentence_count']:,}")
        row[4].metric("Paragraphs", f"{stats['paragraph_count']:,}")
        row2 = st.columns(4)
        row2[0].metric("Unique words", f"{stats['unique_words']:,}")
        row2[1].metric("Avg word length", stats["avg_word_length"])
        row2[2].metric("Longest word", stats["longest_word"] or "—")
        row2[3].metric("Reading time", f"{stats['reading_minutes']} min")

        for warning in threshold_warnings(stats):
            st.warning(warning)

        col_a, col_b = st.columns(2)
        with col_a:
            st.plotly_chart(
                charts.top_words_bar(stats), use_container_width=True
            )
        with col_b:
            st.plotly_chart(
                charts.sentence_length_hist(text), use_container_width=True
            )

        st.subheader("Readability & writing insights")
        read = nlp.readability(text)
        col_r = st.columns(4)
        col_r[0].metric("Flesch reading ease", read["flesch_reading_ease"])
        col_r[1].metric("Flesch-Kincaid grade", read["flesch_kincaid_grade"])
        col_r[2].metric("Syllables", f"{read['syllable_count']:,}")
        col_r[3].metric("Words / sentence", read["words_per_sentence"])
        for insight in nlp.writing_insights(stats):
            st.info(insight)

        st.subheader("Save this analysis")
        if st.session_state.get("just_saved"):
            st.success(st.session_state.just_saved)
            st.session_state.just_saved = None
        save_title = st.text_input("Title", value=title_from(text))
        if st.button("💾 Save to library", type="primary"):
            if not text.strip():
                st.error("Nothing to save — the text is empty.")
            else:
                record = make_record(
                    text, save_title or title_from(text),
                    st.session_state.source,
                )
                saved, _ = storage.add_record(record)
                st.session_state.just_saved = (
                    f"Saved #{saved['id']} “{saved['title']}” — "
                    f"{saved['word_count']:,} words."
                )
                st.rerun()

# ================================================================ LIBRARY
elif page == "Library":
    st.header("Library")
    st.write(
        "Every analysis you save lives here (JSON + CSV on your computer). "
        "Records keep the counts, not the full text — re-paste a text to edit it."
    )
    if not records:
        st.info("Nothing saved yet. Analyze a text and press “Save to library”.")
    else:
        col_s, col_f, col_o = st.columns(3)
        with col_s:
            query = st.text_input("Search titles", "")
        with col_f:
            source_filter = st.selectbox(
                "Source", ["All", "paste", "file", "sample", "import"]
            )
        with col_o:
            sort_by = st.selectbox(
                "Sort by",
                ["Newest first", "Oldest first", "Most words", "Fewest words"],
            )
        found = storage.search_records(
            records,
            keyword=query,
            source="" if source_filter == "All" else source_filter,
        )
        if sort_by == "Newest first":
            found.sort(key=lambda r: str(r.get("created_at", "")), reverse=True)
        elif sort_by == "Oldest first":
            found.sort(key=lambda r: str(r.get("created_at", "")))
        elif sort_by == "Most words":
            found.sort(key=lambda r: r.get("word_count", 0), reverse=True)
        else:
            found.sort(key=lambda r: r.get("word_count", 0))

        st.dataframe(records_frame(found), use_container_width=True)
        st.caption(f"{len(found)} of {len(records)} records shown.")

        selected = None
        if st.session_state.selected_record_id is not None:
            selected = next(
                (r for r in records if r.get("id") == st.session_state.selected_record_id),
                None,
            )
        if selected is not None:
            with st.expander(f"Record #{selected['id']} — {selected['title']}", expanded=True):
                top = selected.get("top_words", [])
                st.write(
                    f"{selected.get('word_count', 0):,} words · "
                    f"{selected.get('char_count', 0):,} characters · "
                    f"{selected.get('sentence_count', 0)} sentences · "
                    f"{selected.get('reading_minutes', 0)} min to read · "
                    f"source: {selected.get('source', '?')}"
                )
                if top:
                    st.write("Top words: " + ", ".join(
                        f"{item['word']} ({item['count']})" for item in top
                    ))

        st.subheader("Open or delete a record")
        for record in found[:50]:
            c1, c2, c3 = st.columns([5, 1, 1])
            c1.write(f"#{record.get('id')} — {record.get('title')} ({record.get('word_count', 0):,} words)")
            if c2.button("Open", key=f"open_{record.get('id')}"):
                st.session_state.selected_record_id = record.get("id")
                st.rerun()
            if c3.button("Delete", key=f"del_{record.get('id')}"):
                remaining = [r for r in records if r.get("id") != record.get("id")]
                storage.save_records(remaining)
                st.session_state.selected_record_id = None
                st.success(f"Deleted #{record.get('id')}.")
                st.rerun()

# ================================================================ SUMMARY
elif page == "Summary":
    st.header("Summary")
    summ = summary.compute_summary(records)
    row = st.columns(4)
    row[0].metric("Texts saved", f"{summ['total_records']:,}")
    row[1].metric("Total words", f"{summ['total_words']:,}")
    row[2].metric("Avg words / text", summ["avg_words_per_record"])
    most = summ["most_frequent_word"]
    row[3].metric(
        "Most frequent word",
        f"“{most}”" if most else "—",
        f"{summ['most_frequent_word_count']} times" if most else "",
    )
    if records:
        col_a, col_b = st.columns(2)
        with col_a:
            st.plotly_chart(
                charts.per_day_line(summ["per_day"]), use_container_width=True
            )
        with col_b:
            st.plotly_chart(
                charts.by_source_bar(summ["by_source"]), use_container_width=True
            )
        if summ["min_record"] is not None:
            st.write(
                f"Shortest: #{summ['min_record']['id']} “{summ['min_record']['title']}” "
                f"({summ['min_record']['word_count']} words) · "
                f"Longest: #{summ['max_record']['id']} “{summ['max_record']['title']}” "
                f"({summ['max_record']['word_count']} words)"
            )
    else:
        st.info("No records yet, so there is nothing to summarize.")

    st.subheader("Export the summary")
    st.write("Download buttons write the same reports the terminal app makes.")
    col_e = st.columns(4)
    md_path = exporters.export_markdown(records, summ)
    with open(md_path, "rb") as handle:
        col_e[0].download_button(
            "⬇ Markdown (.md)", handle.read(),
            file_name=os.path.basename(md_path), mime="text/markdown",
        )
    csv_path = exporters.export_csv_report(records)
    with open(csv_path, "rb") as handle:
        col_e[1].download_button(
            "⬇ CSV (.csv)", handle.read(),
            file_name=os.path.basename(csv_path), mime="text/csv",
        )
    txt_path = exporters.export_audit_log(records)
    with open(txt_path, "rb") as handle:
        col_e[2].download_button(
            "⬇ Audit log (.txt)", handle.read(),
            file_name=os.path.basename(txt_path), mime="text/plain",
        )
    json_bytes = json.dumps(
        {"summary": summ, "records": records}, indent=2, ensure_ascii=False
    ).encode("utf-8")
    col_e[3].download_button(
        "⬇ JSON (.json)", json_bytes,
        file_name="text_stats_summary.json", mime="application/json",
    )

# ================================================================ COMPARE
elif page == "Compare":
    st.header("Compare two texts")
    st.write(
        "How alike are two texts? Jaccard counts the words they share, "
        "cosine counts how similarly they use words."
    )
    st.session_state.setdefault(
        "cmp_a", st.session_state.get("text_input", "") or ""
    )
    col_a, col_b = st.columns(2)
    with col_a:
        st.text_area("Text A", height=200, key="cmp_a",
                     placeholder="Paste the first text…")
    with col_b:
        st.text_area("Text B", height=200, key="cmp_b",
                     placeholder="Paste the second text…")
        sample_titles = ["— load a sample into B —"] + [
            s.get("title", "?") for s in samples
        ]
        picked = st.selectbox(
            "Or load a sample into Text B", sample_titles, key="cmp_sample_pick"
        )
        if picked != "— load a sample into B —":
            chosen = samples[sample_titles.index(picked) - 1]
            st.session_state.cmp_b = chosen.get("text", "")
            st.session_state.cmp_sample_pick = "— load a sample into B —"
            st.rerun()
    if st.button("Compare the two texts", type="primary"):
        text_a = st.session_state.get("cmp_a", "") or ""
        text_b = st.session_state.get("cmp_b", "") or ""
        if not text_a.strip() or not text_b.strip():
            st.error("Paste some text in both boxes first.")
        else:
            sim = nlp.similarity(text_a, text_b)
            col_r = st.columns(2)
            col_r[0].metric("Shared words (Jaccard)", f"{sim['jaccard'] * 100:.0f}%")
            col_r[1].metric("Word use (cosine)", f"{sim['cosine'] * 100:.0f}%")
            set_a = set(cleaned_tokens(text_a))
            set_b = set(cleaned_tokens(text_b))
            shared = sorted(set_a & set_b)
            only_a = sorted(set_a - set_b)
            only_b = sorted(set_b - set_a)
            st.write(
                f"The two texts share {len(shared)} word{'s' if len(shared) != 1 else ''} "
                f"out of {len(set_a | set_b)} different words."
            )
            st.write("**In both:** " + (", ".join(shared) if shared else "none"))
            st.write("**Only in A:** " + (", ".join(only_a) if only_a else "none"))
            st.write("**Only in B:** " + (", ".join(only_b) if only_b else "none"))

# ================================================================ IMPORT
elif page == "Import":
    st.header("Bulk import (CSV)")
    st.write(
        "Upload a CSV with `title` and `text` columns. Every row is checked; "
        "good rows are saved, bad rows are skipped and listed below."
    )
    uploaded = st.file_uploader("Choose a CSV file", type=["csv"])
    if uploaded is not None:
        tmp_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "exports", "_import_tmp.csv",
        )
        os.makedirs(os.path.dirname(tmp_path), exist_ok=True)
        with open(tmp_path, "wb") as handle:
            handle.write(uploaded.read())
        result = importer.import_csv(tmp_path, storage.add_record)
        os.remove(tmp_path)
        st.success(
            f"Imported {result['imported']} row{'s' if result['imported'] != 1 else ''}, "
            f"skipped {result['skipped']}."
        )
        if result["errors"]:
            st.warning("Rows that were skipped:")
            error_df = pd.DataFrame(
                result["errors"], columns=["Row", "Problem"]
            )
            st.dataframe(error_df, use_container_width=True)
        if result["error_log_path"]:
            st.caption(f"Error log saved to: {result['error_log_path']}")
        st.rerun()
