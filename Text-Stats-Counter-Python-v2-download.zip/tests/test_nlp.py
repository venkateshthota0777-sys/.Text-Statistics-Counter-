"""Unit tests for the rule-based NLP helpers (standard library unittest).

Run from the project root with:
    python3 -m unittest discover -s tests -v
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from textstats import engine, nlp


class TestCountSyllables(unittest.TestCase):
    def test_simple_words(self):
        self.assertEqual(nlp.count_syllables("hello"), 2)
        self.assertEqual(nlp.count_syllables("the"), 1)
        self.assertEqual(nlp.count_syllables("cat"), 1)
        self.assertEqual(nlp.count_syllables("beautiful"), 3)

    def test_silent_e_and_le(self):
        # "table" keeps both syllables: the -le ending is its own sound.
        self.assertEqual(nlp.count_syllables("table"), 2)
        # "make" loses the silent e.
        self.assertEqual(nlp.count_syllables("make"), 1)

    def test_empty_and_no_letters(self):
        self.assertEqual(nlp.count_syllables(""), 0)
        self.assertEqual(nlp.count_syllables("123"), 0)
        self.assertEqual(nlp.count_syllables("!!!"), 0)


class TestReadability(unittest.TestCase):
    def test_empty_text_scores_zero(self):
        result = nlp.readability("")
        self.assertEqual(result["flesch_reading_ease"], 0.0)
        self.assertEqual(result["flesch_kincaid_grade"], 0.0)
        self.assertEqual(result["syllable_count"], 0)
        self.assertEqual(result["words_per_sentence"], 0.0)

    def test_short_sentence(self):
        # "Hello world." — 2 words, 1 sentence, 3 syllables.
        result = nlp.readability("Hello world.")
        self.assertEqual(result["flesch_reading_ease"], 77.9)
        self.assertEqual(result["flesch_kincaid_grade"], 2.9)
        self.assertEqual(result["syllable_count"], 3)
        self.assertEqual(result["words_per_sentence"], 2.0)

    def test_punctuation_only(self):
        result = nlp.readability("!!!")
        self.assertEqual(result["flesch_reading_ease"], 0.0)
        self.assertEqual(result["syllable_count"], 0)


class TestSimilarity(unittest.TestCase):
    def test_identical_texts(self):
        result = nlp.similarity("Hello world.", "Hello world.")
        self.assertEqual(result["jaccard"], 1.0)
        self.assertEqual(result["cosine"], 1.0)

    def test_both_empty(self):
        result = nlp.similarity("", "")
        self.assertEqual(result["jaccard"], 1.0)
        self.assertEqual(result["cosine"], 1.0)

    def test_one_empty(self):
        result = nlp.similarity("Hello world.", "")
        self.assertEqual(result["jaccard"], 0.0)
        self.assertEqual(result["cosine"], 0.0)

    def test_fox_and_cat(self):
        # 7 shared words of 9 different ones; "the" appears twice, so
        # cosine is 10/11 — same numbers the website shows.
        a = "The quick brown fox jumps over the lazy dog"
        b = "The quick brown fox jumps over the lazy cat"
        result = nlp.similarity(a, b)
        self.assertAlmostEqual(result["jaccard"], 0.778, places=3)
        self.assertAlmostEqual(result["cosine"], 0.909, places=3)

    def test_nothing_in_common(self):
        result = nlp.similarity("apple banana", "zebra yak")
        self.assertEqual(result["jaccard"], 0.0)
        self.assertEqual(result["cosine"], 0.0)


class TestWritingInsights(unittest.TestCase):
    def test_empty_text_has_no_insights(self):
        self.assertEqual(
            nlp.writing_insights(engine.analyze_text("")), []
        )

    def test_very_short_text(self):
        insights = nlp.writing_insights(engine.analyze_text("Hello"))
        self.assertIn("Very short text: fewer than 10 words.", insights)

    def test_one_word_dominates(self):
        insights = nlp.writing_insights(
            engine.analyze_text("hello hello hello hello")
        )
        self.assertTrue(
            any("dominates" in item for item in insights),
            f"expected a dominance flag, got {insights}",
        )

    def test_very_long_sentences(self):
        long_sentence = " ".join(["word"] * 41) + "."
        insights = nlp.writing_insights(engine.analyze_text(long_sentence))
        self.assertTrue(
            any("Very long sentences" in item for item in insights),
            f"expected a long-sentence flag, got {insights}",
        )

    def test_no_sentences(self):
        # Words with no full stop at all still count as 1 sentence by
        # the engine rule, so no "no sentences" flag fires. But "hello"
        # is 1 of 2 words (50%), so the dominance flag does fire, along
        # with the short-text flag.
        insights = nlp.writing_insights(engine.analyze_text("Hello world"))
        self.assertEqual(insights, [
            'One word dominates: "hello" is 50.0% of all words.',
            "Very short text: fewer than 10 words.",
        ])


if __name__ == "__main__":
    unittest.main()
