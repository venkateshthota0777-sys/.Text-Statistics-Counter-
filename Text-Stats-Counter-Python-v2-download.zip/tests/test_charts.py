"""Unit tests for the Plotly chart builders (standard library unittest).

The builders are plain functions returning a Plotly Figure, so these
tests check the figure data without any browser. Run from the project
root with:  python3 -m unittest discover -s tests -v
"""

import os
import sys
import unittest
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from textstats import charts, engine


class TestTopWordsBar(unittest.TestCase):
    def test_example_text(self):
        stats = engine.analyze_text("Hello world. Hello again!")
        fig = charts.top_words_bar(stats)
        self.assertEqual(len(fig.data), 1)
        words = list(fig.data[0].y)
        counts = list(fig.data[0].x)
        self.assertIn("hello", words)
        self.assertEqual(counts[words.index("hello")], 2)

    def test_empty_analysis(self):
        fig = charts.top_words_bar({"top_words": []})
        self.assertEqual(len(fig.data), 0)


class TestSentenceLengths(unittest.TestCase):
    def test_example_text(self):
        self.assertEqual(
            charts.sentence_lengths("Hello world. Hello again!"), [2, 2]
        )

    def test_no_terminator_is_one_sentence(self):
        self.assertEqual(charts.sentence_lengths("One two three"), [3])

    def test_empty_and_punctuation_only(self):
        self.assertEqual(charts.sentence_lengths(""), [])
        self.assertEqual(charts.sentence_lengths("!!!"), [])


class TestSentenceLengthHist(unittest.TestCase):
    def test_has_data_for_real_text(self):
        fig = charts.sentence_length_hist("Hello world. Hello again!")
        self.assertEqual(len(fig.data), 1)

    def test_empty_text_has_no_data(self):
        fig = charts.sentence_length_hist("")
        self.assertEqual(len(fig.data), 0)


class TestPerDayLine(unittest.TestCase):
    def test_covers_14_days(self):
        today = date.today().isoformat()
        fig = charts.per_day_line({today: 2})
        self.assertEqual(len(fig.data), 1)
        self.assertEqual(len(fig.data[0].x), 14)
        self.assertEqual(sum(fig.data[0].y), 2)
        self.assertEqual(fig.data[0].y[-1], 2)

    def test_empty_history_is_flat_zero(self):
        fig = charts.per_day_line({})
        self.assertEqual(len(fig.data[0].x), 14)
        self.assertEqual(sum(fig.data[0].y), 0)


class TestBySourceBar(unittest.TestCase):
    def test_counts_by_source(self):
        fig = charts.by_source_bar({"paste": 3, "file": 1})
        self.assertEqual(list(fig.data[0].x), ["file", "paste"])
        self.assertEqual(list(fig.data[0].y), [1, 3])

    def test_empty(self):
        fig = charts.by_source_bar({})
        self.assertEqual(len(fig.data), 0)


if __name__ == "__main__":
    unittest.main()
