"""Unit tests for the counting engine (standard library unittest only).

Run from the project root with:
    python3 -m unittest discover -s tests -v
or:
    python3 tests/test_engine.py
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from textstats import engine


class TestAnalyzeText(unittest.TestCase):
    def test_example_from_spec(self):
        stats = engine.analyze_text("Hello world. Hello again!")
        self.assertEqual(stats["word_count"], 4)
        self.assertEqual(stats["sentence_count"], 2)
        self.assertEqual(stats["char_count"], 25)
        self.assertEqual(stats["char_no_space"], 22)
        self.assertEqual(stats["top_words"][0], {"word": "hello", "count": 2})
        self.assertEqual(stats["unique_words"], 3)
        self.assertEqual(stats["avg_word_length"], 5.0)
        self.assertEqual(stats["longest_word"], "hello")
        self.assertEqual(stats["paragraph_count"], 1)
        self.assertEqual(stats["reading_minutes"], 0.0)

    def test_empty_text(self):
        stats = engine.analyze_text("")
        self.assertEqual(stats["word_count"], 0)
        self.assertEqual(stats["char_count"], 0)
        self.assertEqual(stats["char_no_space"], 0)
        self.assertEqual(stats["sentence_count"], 0)
        self.assertEqual(stats["paragraph_count"], 0)
        self.assertEqual(stats["unique_words"], 0)
        self.assertEqual(stats["avg_word_length"], 0)
        self.assertEqual(stats["longest_word"], "")
        self.assertEqual(stats["reading_minutes"], 0.0)
        self.assertEqual(stats["top_words"], [])

    def test_single_sentence(self):
        stats = engine.analyze_text("One.")
        self.assertEqual(stats["word_count"], 1)
        self.assertEqual(stats["sentence_count"], 1)
        self.assertEqual(stats["top_words"], [{"word": "one", "count": 1}])

    def test_no_terminator_counts_as_one_sentence(self):
        stats = engine.analyze_text("Hello world")
        self.assertEqual(stats["word_count"], 2)
        self.assertEqual(stats["sentence_count"], 1)

    def test_sentence_runs_of_punctuation(self):
        stats = engine.analyze_text("Wait... Really?! Yes.")
        self.assertEqual(stats["sentence_count"], 3)

    def test_punctuation_only(self):
        stats = engine.analyze_text("!!! ??? ...")
        self.assertEqual(stats["word_count"], 3)
        self.assertEqual(stats["sentence_count"], 0)
        self.assertEqual(stats["unique_words"], 0)
        self.assertEqual(stats["top_words"], [])

    def test_top_words_sorted_count_then_word(self):
        stats = engine.analyze_text("banana apple banana cherry apple banana")
        self.assertEqual(
            stats["top_words"],
            [{"word": "banana", "count": 3},
             {"word": "apple", "count": 2},
             {"word": "cherry", "count": 1}],
        )

    def test_top_n_limit(self):
        stats = engine.analyze_text("a b c d e f g", top_n=2)
        self.assertEqual(len(stats["top_words"]), 2)

    def test_words_cleaned_of_punctuation_and_case(self):
        stats = engine.analyze_text("Hello, HELLO! (hello)")
        self.assertEqual(stats["word_count"], 3)
        self.assertEqual(stats["top_words"], [{"word": "hello", "count": 3}])

    def test_paragraphs(self):
        stats = engine.analyze_text("First para.\n\nSecond para.\n\n\nThird.")
        self.assertEqual(stats["paragraph_count"], 3)

    def test_reading_time(self):
        stats = engine.analyze_text("word " * 400)
        self.assertEqual(stats["word_count"], 400)
        self.assertEqual(stats["reading_minutes"], 2.0)

    def test_longest_word_first_on_tie(self):
        stats = engine.analyze_text("cats dogs birds")
        self.assertEqual(stats["longest_word"], "birds")
        stats = engine.analyze_text("dogs cats birds")
        self.assertEqual(stats["longest_word"], "birds")

    def test_whitespace_only(self):
        stats = engine.analyze_text("   \n\t  ")
        self.assertEqual(stats["word_count"], 0)
        self.assertEqual(stats["sentence_count"], 0)


class TestThresholdWarnings(unittest.TestCase):
    def test_dominant_word(self):
        stats = engine.analyze_text("spam " * 40 + "eggs beans toast")
        warnings = engine.threshold_warnings(stats)
        self.assertTrue(any("dominates" in w for w in warnings))

    def test_no_warnings_for_normal_text(self):
        stats = engine.analyze_text(
            "The quick brown fox jumps over the lazy dog today.")
        self.assertEqual(engine.threshold_warnings(stats), [])

    def test_long_sentences(self):
        stats = engine.analyze_text(" ".join(["word"] * 50) + ".")
        warnings = engine.threshold_warnings(stats)
        self.assertTrue(any("long sentences" in w for w in warnings))


class TestMakeRecord(unittest.TestCase):
    def test_record_fields(self):
        record = engine.make_record("Hello world.", "Greeting", "paste")
        self.assertEqual(record["title"], "Greeting")
        self.assertEqual(record["source"], "paste")
        self.assertEqual(record["word_count"], 2)
        self.assertEqual(record["sentence_count"], 1)
        self.assertIn("created_at", record)
        self.assertIn("top_words", record)


if __name__ == "__main__":
    unittest.main(verbosity=2)
