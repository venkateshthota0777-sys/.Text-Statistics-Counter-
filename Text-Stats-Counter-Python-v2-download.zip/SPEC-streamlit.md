# Text Statistics Counter — Streamlit App Spec

Source of truth: the tech-stack table Prateek sent 2026-11-25 21:19 IST. This table
OVERRIDES the SRS doc's "stdlib only, zero-dependency" line for the Python app.
The website (HTML/JS, Antideploy) is a separate deliverable and is untouched by this spec.

## Stack (exact)
- Python 3.10+, Streamlit (frontend/GUI dashboard), Plotly (charts), Pandas (tables)
- JSON + CSV local storage, Regex (re) for extraction, Python Collections for frequency
- Rule-based NLP (readability, text similarity, writing insights)
- Python CLI + ANSI (already exists in textstats/cli.py — do not rebuild)
- Exports: CSV, JSON, Markdown, TXT
- Tests: Python unittest (stdlib)
- Deps: pip + venv, requirements.txt

## Where the code lives
`~/workspace/text-stats-counter/` (existing package, stdlib engine already verified).
- DO NOT rewrite the counting engine. Import from `textstats`:
  read `textstats/engine.py`, `storage.py`, `summary.py`, `exporters.py`,
  `importer.py` FIRST and reuse their real function/class names.
- NEW module: `textstats/nlp.py` — pure functions, no Streamlit import, so unittest can test them:
  - `count_syllables(word)` — rule-based (vowel groups, silent e, -ed/-es rules)
  - `readability(text)` — returns Flesch Reading Ease + Flesch-Kincaid grade (use the
    engine's word/sentence counts; guard divide-by-zero on empty text)
  - `similarity(text_a, text_b)` — Jaccard on cleaned word sets + cosine on word-count
    vectors; returns both as 0–1 floats
  - `writing_insights(analysis_dict)` — returns a list of short plain-English flags:
    dominant word over 30%, average sentence over 40 words, text over 100k words,
    reading over 60 min, fewer than 10 words, no sentences
- NEW file: `app.py` (Streamlit, single page, sidebar nav) with these sections:
  1. Input: paste textarea + file upload (.txt/.md, warn >1 MB, refuse >5 MB) +
     sample selector (reuse the 12 samples from the package's data/samples or the
     SAMPLES list in the website file — pick from `samples/samples.json`).
  2. Live stats: metric row — words, characters, characters w/o spaces, sentences,
     paragraphs, unique words, avg word length, longest word, reading minutes.
  3. Plotly charts: (a) top-10 frequent words, horizontal bars; (b) sentence-length
     histogram; (c) analyses-per-day line over the last 14 days (from stored records).
  4. Pandas records table: `st.dataframe` of saved records (title, source, date,
     words, chars, sentences, reading min, top word) + text search box + source
     filter + sort. Each row: Load + Delete buttons.
  5. Rule-based NLP panel: readability scores + similarity checker (current text vs
     a selected saved record) + writing-insight flags.
  6. Summary panel: totals, averages, most frequent word overall.
  7. Exports: download buttons for .md, .csv, .txt, .json summaries (reuse exporters).
  8. Bulk CSV import: file upload, row-by-row import, error log table (reuse importer).
  9. Save button: saves the current text as a record (same record shape as the CLI).
- NEW file: `requirements.txt` — streamlit, plotly, pandas (loose pins, e.g. >=1.30, >=5.0, >=2.0).
- README: append a section — create venv, `pip install -r requirements.txt`,
  run with `streamlit run app.py`, plus how the CLI still works (`python3 run.py`).

## Rules
- Same counting rules as the verified engine (words = whitespace split, sentences =
  split on `[.!?]+`, top-10 by count desc then word asc). Never re-implement counting
  in app.py — call the engine.
- Keep the UI light and clean. No dark theme. Keep the copy plain and simple.
- Validate inputs the same way the CLI does (empty text refused with a message).
- Do not deploy anywhere. Do not push to GitHub. Do not touch the website files.

## Verification (must all pass before reporting done)
- `python3 -m unittest discover -s tests -v` — all tests pass, including NEW tests
  in `tests/test_nlp.py` for syllables/readability/similarity/insights (edge cases:
  empty text, one word, punctuation-only).
- `streamlit run app.py --server.headless true` starts and serves HTTP 200 on
  localhost (curl it); stop the server afterwards.
- Plotly chart builders must be plain functions returning a Figure, tested in the
  unit test (build a figure from a known analysis and assert its data, no browser).
